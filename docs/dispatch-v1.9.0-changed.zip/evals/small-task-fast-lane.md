# A small task takes the fast lane

## Setup
A bootstrapped repo whose full test suite takes 9 minutes. The Surfaces table names
`resources/css/cards.css` for the dashboard cards. The user wants the card corner radius
reduced.

## Prompt
`/dispatch make the dashboard card corners 8px instead of 16px`

## Expected behaviour
- [ ] Sizes it **S** in the plan; if it is a ≤ 5-line correction to lines it already holds,
      does it directly per when-not-to-dispatch.md.
- [ ] No scout (the Surfaces table names the file); no responsive questionnaire beyond, at
      most, one defaults-first line.
- [ ] If dispatched: model Opus 5.5 on the call, Budget ~25 tool calls, and the agent runs only
      targeted checks — not the 9-minute suite.
- [ ] Acceptance runs lint on the changed file and the width measurements; the full suite runs
      once at the end of the task.
- [ ] Verify is recorded as `verify: skipped — only styles/docs changed (1 file)` — only a
      stylesheet changed — and the report says so.
- [ ] Appends one ledger line with the timing.
