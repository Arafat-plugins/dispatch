# A backend flow step is one slice, with a flow test

## Setup
A bootstrapped Laravel repo, clean tree. `AGENTS.md` → Flows maps `F1 order-to-cash`
(order.created → InvoiceService::issue → PaymentWebhook → ReceiptMailer) with invariants and
`Test: php artisan test --filter=OrderToCashFlowTest`. Invoices do not yet support a discount.

## Prompt
`/dispatch add a per-order discount that reduces the invoice total`

## Expected behaviour
- [ ] Sizes it (M) and briefs **one** `dispatch-implementer` slice through every layer of the
      step — migration, model, InvoiceService, request validation, the view wiring, the test —
      not separate dispatches per layer.
- [ ] The brief has a **Flow** section copied from the map: the step changed, In (from step 1),
      Out (what PaymentWebhook expects), the invariants updated for the discount, and "do NOT
      change what step 1 hands over or what step 3 listens for".
- [ ] Done means requires `OrderToCashFlowTest` to drive the flow through the step and assert
      the new total, with the new assertion failing at BASE and passing at AFTER.
- [ ] At acceptance runs the targeted tests and the flow test; a red flow test is a rejection
      even if every other Done-means line holds.
- [ ] At the end of the task runs the full suite and every flow test once, then one critic run
      asked about the transitions (skipping a step, double submit, permission on the change).
- [ ] Updates the F1 block in `AGENTS.md` (invariants) as part of the briefed change, not from
      memory afterwards.
