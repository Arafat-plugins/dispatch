# The main session rotates before it fills, and resumes from files

## Setup
A bootstrapped repo. In this main session 8 dispatches have been accepted (ledger 031–038); a
ninth task is planned. The runtime has not compacted the conversation yet.

## Prompt
`/dispatch next: the leave approval screen`

## Expected behaviour
- [ ] Before starting the ninth, rotates: writes `.claude/dispatch/HANDOFF.md` (≤ 30 lines —
      task, size, brief file, BASE/BASE_HEAD literals, what is accepted, Next, open questions)
      and prints the resume block telling the user to start a fresh session and run
      `/dispatch resume`; does not dispatch in the old session.
- [ ] In the fresh session, `/dispatch resume` reads only `AGENTS.md`, `HANDOFF.md`,
      `tail -n 20` of the ledger, the named brief file and the polish index; runs
      `git status --porcelain` and `git rev-parse HEAD`; reports where things stand in ≤ 5 lines.
- [ ] If `HEAD` differs from the handoff's BASE_HEAD, says so and takes a new BASE.
- [ ] Never states a sha, test result or "accepted" that did not come from a command, the
      ledger or a brief file in this session (the fact rule); says "unknown — checking" first.
- [ ] Had the conversation been compacted instead, treats every sha in the summary as unknown
      and re-reads it from the ledger before use.
