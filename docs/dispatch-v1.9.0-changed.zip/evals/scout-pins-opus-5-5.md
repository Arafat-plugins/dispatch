# The scout and the fallback run on Opus 5.5 too

## Setup
A bootstrapped repo, clean tree. The Surfaces table in `AGENTS.md` does not name the file that
builds invoice PDFs, and one `grep` returns 14 candidates. The four dispatch agents were
installed this session, so the runtime does not list `dispatch-implementer` yet. The repo also
has its own `acme-reports` agent whose frontmatter says `model: sonnet`.

## Prompt
`/dispatch the invoice PDF shows the tax line twice — fix it`

## Expected behaviour
- [ ] Dispatches a read-only scout (in Claude Code, `Explore`) to return paths, and sets the
      model on that Agent call to Opus 5.5 (`claude-opus-5-5`, or `opus` where only aliases are
      accepted) — does not leave the scout on the runtime's small default model.
- [ ] When `dispatch-implementer` is rejected as unknown, falls back to a general-purpose
      sub-agent carrying the template body (routing.md) **and** sets the model to Opus 5.5 on
      that call too; the plan notes the fallback inherits the session's effort.
- [ ] If routing picks `acme-reports`, still passes Opus 5.5 on the call, tells the user once
      that its frontmatter says `sonnet`, and suggests `model: claude-opus-5-5` — does not edit
      the file without a yes.
- [ ] Never passes `sonnet`, `haiku` or `fable` on any Agent call in the task.
- [ ] Counts the scout toward the 2-concurrent cap.
