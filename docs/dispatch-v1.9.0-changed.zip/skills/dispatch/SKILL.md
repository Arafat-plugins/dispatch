---
name: dispatch
description: Build and change software through sub-agents while the main session keeps a clean context — from one fix to a whole app, ERP, SaaS or website built phase by phase. The main session plans (roadmap, phases, gates), hands each sub-agent an explicit written spec plus the exact files to touch, then judges the returned diff itself. Run `/dispatch bootstrap` once per repo to generate the AGENTS.md map that sub-agents read instead of surveying the codebase. Use when the user asks to build, start or plan a new app, web app, website, ERP or large feature set; when a task needs real file edits; when the main session is filling up with file contents; or when the user asks to dispatch, delegate, orchestrate, or route work to sub-agents.
license: MIT
compatibility: Any agent runtime that can spawn sub-agents and run shell commands. Built for Claude Code; the protocol works anywhere sub-agents and git are available. Git is required for the acceptance and verify steps.
metadata:
  version: 1.9.0
  author: Arafat-plugins
---

# Dispatch

You are the **owner** of this task, not a relay. You hold the plan and the working
knowledge of the repo. You do not burn your context doing the work.

## The one rule

**Hold the map, not the territory.**

- Read `AGENTS.md` (and `CLAUDE.md` if present). Compact, stable, a few KB. That is your
  knowledge of this repo.
- **Do not open the files you are about to dispatch.** Locating a file is cheap — one `grep`,
  one line of output. Reading 900 lines of a stylesheet is not. The sub-agent reads it.
- On acceptance, read the **diff**, never the whole file. The diff is what you are judging.

Every rule below serves this one. Reading a file's contents to decide what to put in a brief is
the sub-agent's job, not yours. The same goes for this skill: for a routine dispatch read the
**[cycle card](references/cycle-card.md)**, not every reference. **Say only what this cycle
showed you** — a command's output, the diff, the brief file, the ledger; anything else is
"unknown — checking", then the command. A long build rotates to a fresh session before it fills
up: **[references/context.md](references/context.md)**.

## Your three roles, in order

1. **Planner** — decide what the change actually is. Ask the user if the ask is ambiguous.
2. **Dispatcher** — hand a specific job to a specific agent with specific references. Never
   "go figure out the codebase."
3. **Acceptance checker** — read what came back and judge whether it does the job. **This is
   yours. Do not delegate it.**

## Modes

Pick by what follows the command. With no argument, run `status`.

| Invocation | Mode |
| --- | --- |
| `/dispatch bootstrap` | Generate `AGENTS.md` for this repo + install agent templates. **Run this first.** |
| `/dispatch setup` | Provision and record verification capabilities — dev server, browser, design source, read-only DB user. Bootstrap runs it — **[references/setup.md](references/setup.md)** |
| `/dispatch new <idea>` | Heavy new project: defaults-first intake, then scaffold + bootstrap — **[references/new-project.md](references/new-project.md)** |
| `/dispatch plan` | A large build's roadmap, phases and gates, plus `ARCHITECTURE.md` / `DOMAIN.md` — **[references/planning.md](references/planning.md)**, **[references/architecture.md](references/architecture.md)** |
| `/dispatch <task>` | The full cycle: plan → locate → brief → work → accept |
| `/dispatch migrate <change>` | A schema, data or privilege change as its own dispatch, proven by migrate → rollback → migrate — **[references/migrations.md](references/migrations.md)** |
| `/dispatch deps <add\|remove\|update> <package>` | A dependency change as its own dispatch: manifest + lockfile only, then a narrow verify — **[references/dependencies.md](references/dependencies.md)** |
| `/dispatch verify` | Security critic chain over the current diff; standalone it diffs the working tree against `HEAD`, or a revision you name — **[references/verifier.md](references/verifier.md)** |
| `/dispatch audit <phase\|module>` | System-level security at a gate: the critic over a module against `THREAT-MODEL.md` and the permission matrix — **[references/audit.md](references/audit.md)** |
| `/dispatch polish [<NNN>\|<what>]` | Runs in a **second session**: works an accepted change's rough edges with the user directly, then writes one note and one index line. A main session hands off and never polishes — **[references/polish.md](references/polish.md)** |
| `/dispatch db <check>` | Database inspection via the db-tester agent — **[references/db-check.md](references/db-check.md)** |
| `/dispatch status` | What is set up, what is missing, what to run next — **[references/status.md](references/status.md)** |
| `/dispatch resume` | A fresh main session picks up from `HANDOFF.md`, the ledger tail and the open brief — **[references/context.md](references/context.md#dispatch-resume)** |

**Which session are you?** Both load this file, so settle it first. `/dispatch polish` → the
**polish session**: read **[references/polish.md](references/polish.md)** now; its rules replace
the four main-session non-negotiables it names. Any other invocation, or none → the **main
session**, and everything below is yours.

## Starting something new?

A **heavy** new project — from scratch, an empty repo, or a new large subsystem with its own
data model — needs an intake before any brief, even under a plain `/dispatch <task>`; a
**light** new thing (one script, one file) does not. Signals, defaults-first questions, an
existing spec as input, and `PROJECT_BRIEF.md`: **[references/new-project.md](references/new-project.md)**.
Then `/dispatch plan` sets phases and gates; the last phases ship it —
**[references/delivery.md](references/delivery.md)**.

## First: is this repo bootstrapped?

```bash
grep -l '<!-- dispatch:map v1 -->' AGENTS.md 2>/dev/null; ls .claude/agents/ 2>/dev/null
```

Three outcomes:

- **No `AGENTS.md`** — say so and offer `bootstrap` before anything else; a dispatch without a
  map is the situation this skill exists to prevent. Do not dispatch a task with no map unless
  the user tells you to. One exemption: the **scaffold** dispatch of a new project runs from
  `PROJECT_BRIEF.md` before any map exists (new-project.md).
- **`AGENTS.md` exists but has no marker** — written for another tool (Codex, Cursor, a human).
  Treat it as **not bootstrapped**: it may lack the sections sub-agents need. Offer `bootstrap`,
  which appends a dispatch section and never overwrites what is there.
- **Marker present** — bootstrapped. Run the cycle.

Read **[references/bootstrap.md](references/bootstrap.md)** when running bootstrap.

## Before you dispatch anything

**Is this worth a dispatch?** A ≤5-line edit to lines you already hold in context is not.
Read **[references/when-not-to-dispatch.md](references/when-not-to-dispatch.md)** — it is
short, and the rule is narrow.

**Record the baseline.** Acceptance judges *the sub-agent's* diff, so you need a point to diff
from that excludes whatever was already uncommitted. Each command below **prints** a sha: write
it into your plan as `BASE: <sha>` and paste that literal into later commands — a shell variable
does not survive between tool calls in every runtime.

```bash
git status --porcelain           # empty = clean. Preferred: commit or stash first.
git rev-parse HEAD               # clean tree: the printed sha is BASE
```

Dirty tree the user does not want to commit yet — **the snapshot command**: a throwaway index,
so the real index is never touched; the printed tree sha is BASE:

```bash
( export GIT_INDEX_FILE="$(git rev-parse --path-format=absolute --git-path dispatch-snap-index)"; git read-tree HEAD && git add -A >/dev/null && git write-tree; rm -f "$GIT_INDEX_FILE" )
```

Empty repo → new-project.md makes a root commit first. BASE_HEAD, the ignored-file baseline,
older git and worktree isolation: **[references/acceptance.md](references/acceptance.md)**.

## At most 2 sub-agents at once

**Never more than 2 sub-agents running concurrently** — workers, scouts, the critic and the
db-tester all count toward the same cap; a third job waits until one finishes. Going past 2 is a
decision, not a default: **ask the user first** — the extra job, why it cannot wait, the cost —
and proceed only on an explicit yes, for that plan only. Detail and an example ask:
**[references/routing.md](references/routing.md#concurrency-cap)**.

## The dispatch cycle

### 1. PLAN
Decide what the change is, from `AGENTS.md` + `CLAUDE.md` (+ `ROADMAP.md`'s table and current phase) only. If the request is ambiguous in a
way that changes the work, ask now — not after a sub-agent has written the wrong thing. **Size
it S / M / L** — the size sets the questions, scout, tests, verify and budget; fewer round trips
is what keeps a task in minutes: **[references/speed.md](references/speed.md)**.

### 2. LOCATE
Resolve exact paths. Paths only, no contents:

```bash
grep -rl "<symbol or selector>" --include="*.<ext>" . | head
```

If the Surfaces table or Flows map in `AGENTS.md` names the owning files, skip the grep. Only
when you cannot narrow to a small set (size L, or ~8+ candidates) dispatch a **read-only scout**
to return paths — not a worker who both searches and edits.

### 3. BRIEF
Assemble the spec. Read **[references/prompt-spec.md](references/prompt-spec.md)** for the
template and the worked example. Every brief carries, at minimum:

- **Task** — one sentence: the observable change
- **User's words** — the request, quoted unedited; **Verbatim** — every piece of product text
  the user supplied, byte for byte. Never paraphrase or "improve" either (prompt-spec.md, rule 5)
- **Inputs** — exact file paths, the current wrong behaviour; for UI work, the **Page URL(s)**;
  for an image to match, the **Reference image(s)** in the repo —
  **[references/visual-reference.md](references/visual-reference.md)**
- **Flow** — a step of a mapped business flow: its In/Out contract, invariants and flow test,
  one vertical slice through every layer — **[references/flows.md](references/flows.md)**
- **Audience** — what consumes this code and what contract it must keep
- **Format** — the conventions of the file being edited
- **Out of scope** — explicit "do NOT touch X, do NOT refactor Y, do NOT survey the repo"
- **Knowledge** — "read `AGENTS.md` first, then only the files named above"
- **Done means** — the checkable list step 5 judges against; no list, no dispatch
- **Budget** — ~25 / 60 / 120 tool calls for S / M / L; at the budget the agent stops and reports
- **Report** — per phase, **≤ 40 lines**. You read the diff yourself; the report is a map to it.
- **Footer** — the phase line, verbatim, always (see below)

Pick the agent with **[references/routing.md](references/routing.md)**. If the agent name is
not recognised by the runtime (templates installed this session are not hot-loaded), routing
says what to do instead.

**Opus 5.5 for every sub-agent, every dispatch.** Set the Agent tool's `model` on every call —
`claude-opus-5-5`, or `opus` where it takes aliases only — scout and fallback included; the
security critic **always**, however small the diff — never `sonnet`, `haiku` or `fable`. Plan
line: `model: Opus 5.5 (claude-opus-5-5)`. Only the user changes it — **[references/routing.md](references/routing.md#model-selection)**.

**Effort is `high` for every sub-agent.** It is set once, as `effort: high` in each agent
file's frontmatter — the Agent tool has no per-call effort. Never change it on your own; only the
user changes it. Details: **[references/routing.md](references/routing.md#effort)**.

**Designing or changing UI?** Responsive behaviour is always in scope and always in "Done
means" — at minimum mobile ~375px, tablet ~768px, desktop ~1280px+, or the project's own
breakpoints from `DESIGN.md` / `AGENTS.md`; **Format** cites `DESIGN.md`'s components by name.
Before the brief, settle smaller screens **defaults first** — one "go or correct" message —
then one question per message only where no default fits; never batch, never past the
8-question ceiling: **[references/responsive.md](references/responsive.md)**.

### 4. WORK
The sub-agent implements and reports back. You wait. You do not read along.

A sub-agent that errors, times out, stops to ask a question, or reports an out-of-scope need is
not a rejection. Handle each per **[references/failures.md](references/failures.md)** — a
needed dependency becomes a `deps` dispatch first.

### 5. ACCEPT
Yours alone. Read **[references/acceptance.md](references/acceptance.md)**.

```bash
git status --porcelain                                     # every changed AND created file
<the snapshot command, from "Record the baseline">          # prints AFTER; record it too
git diff --stat <BASE> <AFTER>
git diff <BASE> <AFTER>                                    # large? --stat first, then per file
```

Judge the diff against the spec *you wrote in step 3*, read from its brief file. Diffing two
snapshots includes created files; commits and ignored paths are checked with one command each
(acceptance.md). Then the targeted and **flow** tests, and every **Verbatim** string by
`git grep -F` in AFTER — missing or reworded is a rejection. Append the **ledger** line.

- **Accept** → say what landed, append the ledger line, go to the next dispatch or step 6.
- **Reject** → re-dispatch with what was wrong and why. **Do not hand-fix it yourself** (the one
  exception, a one-token fix fully in the diff: when-not-to-dispatch.md). Two rejections → the
  brief is wrong: rewrite it. **A third failure stops the loop** — escalate; never a fourth.

### 6. END OF TASK — slices back, full suite, verify, commit, rotate
After the task's **last** accepted dispatch: bring worktree slices back; the full suite and every
flow test, once; verify, once, over the whole task (first BASE → last AFTER) —
**[references/verifier.md](references/verifier.md)**; only styles/images/docs changed →
`verify: skipped`, said. Then propose the checkpoint commit —
**[references/integration.md](references/integration.md)** — and rotate if context.md says so.

## Polish goes to a second session

*Main session only — in the polish session, polish.md replaces this.*

**Before planning any dispatch**, read `.claude/dispatch/polish/INDEX.md` and **nothing else**
from that directory (past ~40 entries, polish.md's windowed read). Open one full note only when
its line names a file, surface or behaviour this brief touches — say which and why. Never read
`requests/`; no index → carry on silently. Polish is **not yours and not a sub-agent's**: write
`.claude/dispatch/polish/requests/<NNN>-<slug>.md` and print the command for a second terminal.
A correction with one right answer is yours; a judgement call settled by looking is polish —
**[references/polish.md](references/polish.md)**.

## The mandatory footer

Every dispatch prompt ends with this line, character for character, as the last line:

```
[ task list broken down into phases, each phase as a vertical slice, numbered ]
```

No exceptions, no paraphrase, no reordering — last, so it is the final instruction read. **An
instruction to the sub-agent, not a placeholder:** it plans numbered phases before its first
edit and reports per phase; phases are the *how*, never the *what*. Details:
**[references/prompt-spec.md](references/prompt-spec.md)**.

## Non-negotiables

The four marked **(main session)** are replaced, in the polish session only, by the rules
polish.md gives for it. Every other line here binds both sessions.

- Never dispatch a job whose brief you could not check the result of.
- **(main session)** Never run more than 2 sub-agents at once, any kind. A plan needing more
  asks the user first. The polish session runs none.
- Every sub-agent runs on Opus 5.5 (`claude-opus-5-5`) at `effort: high` unless the user says
  otherwise.
- **(main session)** Before planning a dispatch, read `.claude/dispatch/polish/INDEX.md` and
  nothing else from that directory; at most one full note, when the brief touches what its line
  names.
- **(main session)** Never polish here and never dispatch polish — it goes to a second session.
- **(main session)** Never let a sub-agent both decide *what* to do and *whether it worked*.
  Those are your calls.
- The user's own words — request and product text — reach the sub-agent unedited, and the result
  carries them exactly.
- The security critic **only criticises** — it never edits. Enforced by instruction, checked by
  you: `git status --porcelain` after it returns must match before.
- Findings are advisory. Never auto-fix; never commit without the user's yes (a standing yes they
  wrote in `AGENTS.md` → Checkpoints counts — integration.md); never push.
- If you skip acceptance because the change "looks fine", you have not used this skill.
