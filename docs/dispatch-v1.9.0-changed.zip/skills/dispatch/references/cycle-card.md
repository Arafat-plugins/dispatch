# Cycle card — a routine dispatch on one page

Read this card instead of routing.md, prompt-spec.md, acceptance.md and verifier.md for a
**routine** dispatch. Open the full reference only where a line below sends you to it
([context.md](context.md)). "Routine" means the repo is bootstrapped, you have briefed this kind
of work here before, and nothing below has failed.

## 0. Before the task

- `tail -n 20 .claude/dispatch/ledger.md` and `.claude/dispatch/polish/INDEX.md`, and nothing
  else from either directory.
- **Size it**: S / M / L, written into the plan ([speed.md](speed.md)).
- **Model**: `model: Opus 5.5 (claude-opus-5-5)` on every Agent call, the scout included.
- The user's messages that define the task: copy them, **unedited**, for *User's words* and
  *Verbatim*.

## 1. Locate — paths only

Surfaces table → Flows map → `grep -rl` → `git grep -n`. Use a scout only for size L or for more
than ~8 candidates.

## 2. Brief — to a file first

Next number (context.md), then write `.claude/dispatch/briefs/<NNN>-<slug>.md` (and any
reference image) **before** step 3's BASE, so neither shows up as a change in the diff:

```
## Task
<one sentence>

## User's words
<quoted exactly>

## Inputs
Files you may edit: <paths>
Current wrong behaviour: <measured>
Target behaviour: <checkable>
Page URL(s): <UI only>
Reference image(s): <image given only — visual-reference.md>

## Audience
<what consumes this code; the contract it keeps>

## Format
<the edited file's conventions; DESIGN.md components by name for UI>

## Verbatim — use exactly
<user-supplied product text, byte for byte — or delete>

## Flow
<a mapped flow step only — flows.md — or delete>

## Out of scope — do NOT
- do NOT touch <…>; do NOT survey the repo; do NOT commit; do NOT add dependencies

## Knowledge
Read AGENTS.md first, then only the files above.

## Done means
- [ ] <checkable> · [ ] <test that fails at BASE, for logic> · [ ] <Verbatim strings present>
- [ ] you report per phase: what changed, verified / not verified

## Budget
<S ~25 | M ~60 | L ~120> tool calls; at the budget, stop and report.

## Report
At most 40 lines.

[ task list broken down into phases, each phase as a vertical slice, numbered ]
```

First UI brief, first flow brief, first image brief, or a deps change → open prompt-spec.md,
responsive.md, flows.md, visual-reference.md or dependencies.md for that one.

## 3. Baseline — print it, record it

```bash
git status --porcelain
git rev-parse HEAD                        # clean → BASE (and BASE_HEAD)
```

Dirty tree → the snapshot command in SKILL.md prints BASE. Write `BASE:` and `BASE_HEAD:` into
the plan as literals.

## 4. Dispatch

Agent from `AGENTS.md`'s role list, the model set on the call, at most 2 running at once.
Then wait; do not read along.

## 5. Accept — yours

```bash
git status --porcelain
<snapshot command>                                           # AFTER
git diff --stat <BASE> <AFTER>
git diff <BASE> <AFTER> -- . ':(exclude)*.lock' ':(exclude)package-lock.json'
git log --oneline <BASE_HEAD>^{commit}..HEAD                 # must be empty
git grep -n -F -e '<each Verbatim line>' <AFTER> -- <briefed paths>
<lint on changed files> ; <targeted tests + flow tests>
```

Go through Done means line by line. Unbriefed files, large deletions, TODOs, a missing Verbatim
string, or a red flow test → **reject** (quote it, and edit the brief file). UI → measure the
widths, plus `--compare` for a reference image and open the composite. Over ~300 lines, commits,
ignored files, or anything odd → acceptance.md.

Append the ledger line.

## 6. End of task

- The full suite and every flow test, **once**.
- Verify, **once**, over the first BASE to the last AFTER. Skip it only when every path is a
  stylesheet, an image or a doc ([speed.md](speed.md#verify--once-per-task-and-not-for-pure-style)).
  Otherwise verifier.md.
- Report `Accepted / Verified / Not verified`, plus the timing line.
- **Rotate?** 8 accepted this session, a phase done, or the conversation compacted →
  `HANDOFF.md` and the resume block ([context.md](context.md#rotate-the-session--do-not-let-it-grow)).
