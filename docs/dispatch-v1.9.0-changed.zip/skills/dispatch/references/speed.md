# Speed — sizing a task so it finishes in minutes, not hours

A task that takes 2–3 hours through dispatch almost never has one slow step. It has many round
trips, each of them justified on its own. Up to 1.7.0 a single UI change could go:

| Round trip | Where it came from |
| --- | --- |
| up to 8 one-at-a-time questions, each waiting on the user | responsive.md, new-project.md |
| a scout sub-agent to find files | SKILL.md, LOCATE |
| the worker, running the **full** test suite (up to 10 min) | dispatch-implementer.md |
| acceptance re-running the full suite | acceptance.md |
| the security critic, **every** dispatch, even for CSS | SKILL.md, VERIFY |
| backend split by layer into 2–4 dispatches, run in sequence | routing.md, "one job per dispatch" |
| up to 3 attempts, each repeating all of the above | failures.md |

Every sub-agent runs on Opus 5.5 at `effort: high` (routing.md), so each extra run is a slow
one. The fix is not to think less, which is the user's choice (`effort:`). The fix is **fewer
runs**, sized to the task.

## Size every task first — S, M or L

Put the size in the plan (`size: M`) before LOCATE. It decides the ceremony:

| | **S** — small | **M** — medium | **L** — large |
| --- | --- | --- | --- |
| Looks like | one surface or one step, ≤ 3 files, a known pattern | one feature slice, ≤ ~8 files | a new module, a new flow, cross-cutting |
| Questions before the brief | 0–1 | defaults-first, one confirmation | defaults-first, then at most the ceiling |
| Scout | never (grep or the Surfaces table) | only if grep returns > 8 candidates | allowed |
| Dispatches | 1 | 1 per flow step or surface | 1 per slice, planned up front |
| Tests in the dispatch | targeted | targeted + flow test | targeted + flow test |
| Full suite | once, at the end of the task | once, at the end of the task | once, at the end of the task |
| Critic | once per task, or skipped for pure style (below) | once per task | once per task |
| Brief Budget | ~25 tool calls | ~60 | ~120 |

A task that grows past its size while you plan is **re-sized, and the user is told** in one line.
A ≤ 5-line correction is not a dispatch at all ([when-not-to-dispatch.md](when-not-to-dispatch.md)).

## Questions — defaults first, one confirmation

The biggest time sink was waiting between questions. Do not ask what you can propose. For UI
work ([responsive.md](responsive.md)) and new projects ([new-project.md](new-project.md)),
**write your default for every open point and ask once**:

```
Before I brief it — here is how I'll build it unless you change a line:
- Mobile nav: hamburger at ≤ 768px (DESIGN.md has no nav pattern)
- 3-column grid → 1 column ≤ 620px, 2 up to 900px (the file's existing breakpoints)
- Table on mobile: horizontal scroll
Say "go", or correct any line.
```

That is **one** question in the ceiling's count. Ask a real one-at-a-time question only when
there is no sensible default, such as brand colours or which of two flows the user means. The
one-question-per-message rule still holds; this message *is* one question.

## Locate without a scout

In order: the Surfaces table, the Flows map, one `grep -rl`, one `git grep -n`. A scout is an
extra Opus 5.5 run. Dispatch one only for size L, or when grep returns more than ~8 candidates
and none is obviously the owner.

## Tests — targeted per dispatch, full once per task

- **In the dispatch** the agent runs lint on changed files, the targeted tests for them, and
  the brief's flow test (`AGENTS.md` → Commands → *Test (targeted)*).
- **At acceptance** you run the same targeted commands, plus the flow check.
- **Once per task**, after its last dispatch is accepted, you run the **full** suite (every
  shard) and every flow test. A red test there that is not in the known-failing baseline means
  you find which accepted dispatch caused it with `git diff --stat` per ledger entry, and
  re-dispatch that one brief with the failure quoted.

Running the full suite in every agent run *and* every acceptance was the single biggest cost on
a large repo. GoodTechies HQ's suite needed nine shards and still timed out as one process.

## Verify — once per task, and not for pure style

- **Batch it.** Run one critic over the task's combined diff (the first dispatch's BASE to the
  last dispatch's AFTER) after the last acceptance, not one critic per dispatch. The scout stage
  is the same: you already read every hunk.
- **Skip it for pure style and docs.** When every changed path is a stylesheet (`.css`,
  `.scss`, `.less`), an image, or documentation (`.md`, `.txt`) and nothing else, the risk
  table's answer is "none". Write `verify: skipped — only styles/docs changed (<N> files)` in
  the plan and the report. Templates, markup, copy inside code, config and lockfiles are **not**
  pure style: they still get the critic.
- **Deps briefs** still get their own narrow verify ([dependencies.md](dependencies.md)).
- The critic is still Opus 5.5 whenever it runs (routing.md).

## Budgets — stop runaway agents

Every brief carries a **Budget** line (prompt-spec.md): about 25 / 60 / 120 tool calls for S / M
/ L. An agent at its budget stops and reports what is done and what is left. That is not a
failure (failures.md, case 3 treats it like a question). It stops an agent from spending an hour
re-reading files after it is stuck. Re-dispatch the remainder as its own brief.

## Parallel where it is safe

Two briefs with disjoint files and **no shared flow** can run at once in separate worktrees,
within the cap of 2 (routing.md). A worker on slice B can run while you accept slice A.

**Bring an accepted worktree slice back** before the next slice that needs it, and always before
the end-of-task run: `git diff --binary | git apply`, then both slices' tests together
([integration.md](integration.md#1-bringing-a-worktree-slice-back)). The end-of-task full suite
and verify run **after every slice is back**, with AFTER taken from your own tree.
The critic also waits for an idle tree, which is one more reason to run it once per task.

## What to report

End each task with one timing line in the ledger and the report:
`task 007: 3 dispatches, 1 rejection, critic 1×, full suite 1× — 41 min`. When tasks keep
landing over an hour, the ledger shows which round trip is to blame.
